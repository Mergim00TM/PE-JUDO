﻿using System;
using System.Windows;

namespace JudoRef.Wpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string naam1 = "";
        private string naam2 = "";
        private string gordel1 = "";
        private string gordel2 = "";
        int score1;
        int score2;
     
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void BeginSituatie()
        {
            stpScore1.Visibility = Visibility.Hidden;
            stpScore2.Visibility = Visibility.Hidden;
            lstScoreTabel.Visibility = Visibility.Hidden;
            lstScoreTabel.Items.Clear();
            btnStopWedstrijd.Visibility = Visibility.Hidden;
        }

        private void VerwerkScoreJudoka1(int punten, string scoreNaam)
        {
            DateTime date = DateTime.Now;
            score1 = score1 + punten;
            lblScore1.Content = score1;
            lstScoreTabel.Items.Add($"{date}: {naam1} ({gordel1}) scoort {punten} met een {scoreNaam} ");
        }

        private void VerwerkScoreJudoka2(int punten, string scoreNaam)
        {
            DateTime date = DateTime.Now;
            score2 = score2 + punten;
            lblScore2.Content = score2;
            lstScoreTabel.Items.Add($"{date}: {naam2} ({gordel2}) scoort {punten} met een {scoreNaam} ");
        }


        private void VulcomboxGordels()
        {
            cmbGordel1.Items.Add("Wit");
            cmbGordel1.Items.Add("geel");
            cmbGordel1.Items.Add("oranje");
            cmbGordel1.Items.Add("groen");
            cmbGordel1.Items.Add("blauw");
            cmbGordel1.Items.Add("bruin");
            cmbGordel1.Items.Add("zwart");

            cmbGordel2.Items.Add("Wit");
            cmbGordel2.Items.Add("geel");
            cmbGordel2.Items.Add("oranje");
            cmbGordel2.Items.Add("groen");
            cmbGordel2.Items.Add("blauw");
            cmbGordel2.Items.Add("bruin");
            cmbGordel2.Items.Add("zwart");
            //Selecteer eerste waarde
            cmbGordel2.SelectedIndex = 0;
            cmbGordel1.SelectedIndex = 0;

        }
                          
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Title = "Judoref - Mergim Topallaj";
            VulcomboxGordels();
            BeginSituatie();
        }

        private void BtnStartKamp_Click(object sender, RoutedEventArgs e)
        {
            naam1 = txtJudoka1.Text;
            naam2 = txtJudoka2.Text;
            gordel1 = cmbGordel1.SelectedItem.ToString();
            gordel2 = cmbGordel2.SelectedItem.ToString();
            lstScoreTabel.Visibility = Visibility.Visible;
            btnStopWedstrijd.Visibility = Visibility.Visible;
            stpScore1.Visibility = Visibility.Visible;
            stpScore2.Visibility = Visibility.Visible;

            lstScoreTabel.Items.Add($"Start kamp tussen {naam1} (Gordel {gordel1}) en {naam2}" +
                $" (Gordel {gordel2})");
        }
        
        private void BtnStopWedstrijd_Click(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Process.Start(Application.ResourceAssembly.Location);
            Application.Current.Shutdown();
        }

        private void BtnKoka1_Click(object sender, RoutedEventArgs e)
        {
            VerwerkScoreJudoka1(3, "Koka");
        }

        private void BtnKoka2_Click(object sender, RoutedEventArgs e)
        {
            VerwerkScoreJudoka2(3, "Koka");
        }

        private void BtnYuko1_Click(object sender, RoutedEventArgs e)
        {
            VerwerkScoreJudoka1(5, "Yuko");
        }

        private void BtnYuko2_Click(object sender, RoutedEventArgs e)
        {
            VerwerkScoreJudoka2(5, "Yuko");
        }

        private void BtnWazeri1_Click(object sender, RoutedEventArgs e)
        {
            VerwerkScoreJudoka1(7, "Wazeri");
        }

        private void BtnWazeri2_Click(object sender, RoutedEventArgs e)
        {
            VerwerkScoreJudoka2(7, "Wazeri");
        }

        private void BtnIppon1_Click(object sender, RoutedEventArgs e)
        {
            VerwerkScoreJudoka1(25, "Ippon");
        }

        private void BtnIppon2_Click(object sender, RoutedEventArgs e)
        {
            VerwerkScoreJudoka2(25, "Ippon");
        }
    }
}
